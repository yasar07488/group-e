import random
import csv

with open("data/prova-yasar07488.csv", "w", newline="", encoding="utf-8") as dosya:
    yazici = csv.writer(dosya)
    yazici.writerow(["deger"])

    for _ in range(10):
        yazici.writerow([random.randint(1, 100)])
